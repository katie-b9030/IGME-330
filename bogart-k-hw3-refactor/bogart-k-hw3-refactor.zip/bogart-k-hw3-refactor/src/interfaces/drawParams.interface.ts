interface DrawParams { 
	showGradient: boolean,
	showBars: boolean,
	showNoise: boolean, 
	showInvert: boolean, 
	showEmboss: boolean
}