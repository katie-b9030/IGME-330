interface ColorStop{
    percent:number,
    color:string
}