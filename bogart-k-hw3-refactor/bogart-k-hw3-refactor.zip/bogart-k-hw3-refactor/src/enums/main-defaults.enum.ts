// 1 - here we are faking an enumeration
enum DEFAULTS {
    sound1 = "media/New Adventure Theme.mp3"
  }