// 3 - here we are faking an enumeration
enum DEFAULTS{
    gain = .5,
    numSamples = 256
}